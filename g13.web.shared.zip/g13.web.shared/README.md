# G13.Web.Shared

## tip

```cmd
yarn link
```

You can now run `yarn link "g13-web-shared"` in the projects where you want to use this package and it will be used instead.
