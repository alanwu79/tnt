import { KoaRouterFactory } from './KoaRouterFactory';

export { KoaRouterFactory }
