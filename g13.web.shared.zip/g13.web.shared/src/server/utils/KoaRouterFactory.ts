import compose, { Middleware } from 'koa-compose';
import Koa, { ParameterizedContext } from 'koa';
import Router, { IRouterParamContext } from 'koa-router';

type RouteMethod = "GET" | "POST" | "PUT" | "DELETE";

export interface KoaRouterFactoryOptions {
    [key: string]: {
        action: string;
        method: RouteMethod
        controller: Middleware<
            ParameterizedContext<any, IRouterParamContext<any, {}>>>
    }
}
export class KoaRouterFactory {

    static create = (prefix: string, options: KoaRouterFactoryOptions): Middleware<ParameterizedContext<any, IRouterParamContext<any, {}>>> => {
        const router = new Router();
        const defaultStatus = async (ctx: Koa.Context, next: Koa.Next): Promise<void> => {
            await next();
        };

        Object.keys(options).map((key) => {
            const option = options[key];
            const action = option.action;
            const controller = compose([defaultStatus, option.controller]);

            switch (option.method) {
                case "GET":
                    router.get(action, controller);
                    break;
                case "POST":
                    router.post(action, controller);
                    break;
                case "PUT":
                    router.put(action, controller);
                    break;
                case "DELETE":
                    router.delete(action, controller);
                    break;
                default:
                    break;
            }
        });

        router.prefix(prefix);

        return compose([router.allowedMethods(), router.routes()]);
    }
}
