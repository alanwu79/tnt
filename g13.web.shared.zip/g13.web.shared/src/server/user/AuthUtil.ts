import jwt from 'jsonwebtoken';
import Router from 'koa-router';
import { AuthJwtDTO } from './models/JwtDTO';
import { ParameterizedContext } from 'koa';
/// <reference types="../../../@types/koa-bearer-token/" />

export class AuthUtil {
    static AuthHeader = "authorization"

    static newBearer(token: string): string {
        return `Bearer ${token}`
    }

    static parseBearer(bearer: string): string {
        try {
            if (bearer.indexOf("Bearer") >= 0) {
                return bearer.slice(7);
            }
            return bearer;
        } catch {
            return ''
        }
    }

    static getToken(
        ctx: ParameterizedContext<any, Router.IRouterParamContext<any, {}>>,
        key: string): string | undefined {
        // @ts-ignore
        let token = ctx.request.token;

        if (!!token) {
            return token;
        }

        if (!ctx.state.isApi) {
            token = ctx.cookies.get(key);
        }

        return token;
    }

    /**
     * @param  {any} payload
     * @param  {string} secret
     * @param  {number|string} ttl Eg: 60, "2 days", "10h", "7d", default '1h'
     */
    static sign(payload: any, secret: string, ttl: number | string = '1h') {

        let token = jwt.sign({
            data: payload
        }, secret, { expiresIn: ttl });

        return token
    }

    static verify(token: string, secret: string): boolean {

        return !!AuthUtil.decode(token, secret);
    }

    static decode(token: string, secret: string): AuthJwtDTO {

        if (token == "" || typeof token == "undefined") {
            return undefined;
        }

        try {

            const decoded = jwt.verify(token, secret) as AuthJwtDTO;

            return decoded;
        } catch (error) {

            console.log(error)

            return undefined;
        }
    }

}
