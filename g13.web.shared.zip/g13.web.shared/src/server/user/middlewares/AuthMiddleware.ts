import Router from 'koa-router';
import { AuthUtil } from '../AuthUtil';
import { ParameterizedContext } from 'koa';

function matchesPath(url: URL, opts: { path: any; }) {
    var paths = !opts.path || Array.isArray(opts.path) ?
        opts.path : [opts.path];

    if (paths) {
        return paths.some(function (path: string | RegExp) {
            return (typeof path === 'string' && path === url.pathname) ||
                (path instanceof RegExp && !!path.exec(url.pathname));
        });
    }

    return false;
}

export function AuthMiddleware(
    key: string, secret: string, whitelist: RegExp[] | string[]) {
    return async (
        ctx: ParameterizedContext<any, Router.IRouterParamContext<any, {}>>,
        next: () => any) => {

        console.log(ctx.request.URL.href);

        const token = AuthUtil.getToken(ctx, key);
        const verify = AuthUtil.verify(token, secret);

        if (verify) {
            // console.log("Auth Verify");
            return next();
        }

        const skip = matchesPath(ctx.request.URL, { path: whitelist })

        if (skip) {
            // console.log("Auth SKIP");
            return next();
        }

        // console.log("Auth Middleware unauthorize");

        ctx.status = 401
        ctx.cookies.set(key, "", { maxAge: -1 });

        if (!ctx.state.isApi) {
            ctx.redirect("/login");
        }

        return;
    };
}
