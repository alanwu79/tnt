
import jwt from 'jsonwebtoken';
import { AuthUtil } from '..';
import { AuthJwtDTO } from '../models/JwtDTO';

const ActiveLogoutTokens: AuthJwtDTO[] = [];

export class AuthUserRepository {

  static login(token: string, secret: string): void {
    try {

      const decoded = AuthUtil.decode(token, secret)

      // console.log(decoded);

      const dto = decoded.data;

      if (!!dto.id && !!ActiveLogoutTokens[dto.id]) {
        delete ActiveLogoutTokens[dto.id];
      }

    } catch (error) {
      throw error;
    }
  }

  static logout(token: string, secret: string): void {
    try {

      const decoded = AuthUtil.decode(token, secret)

      ActiveLogoutTokens[decoded.data.id] = decoded.data;

    } catch (error) {
      console.log(error);
    }
  }

  static verify(token: string, secret: string): boolean {
    try {
      const decoded = jwt.verify(token, secret) as AuthJwtDTO;

      const dto = ActiveLogoutTokens[decoded.data.id];

      return typeof dto == "undefined";
    } catch (error) {
      console.log(error);
      return false;
    }
  }

  static display() {
    console.log({ ActiveLogoutTokens });
  }
}
