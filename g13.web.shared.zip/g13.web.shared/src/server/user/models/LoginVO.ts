
export interface LoginVO {
    username: string;
    password: string;
}
