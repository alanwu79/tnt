
export interface InviteUserVO {
    email?: string;
    role_id: number;
    parent_id: string;
    operator_id: string;
}
