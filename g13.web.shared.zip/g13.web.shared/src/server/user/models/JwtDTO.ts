
export interface JwtDTO<T> {
    data: T;
    iat?: number;
    exp?: number;
}

interface AuthDTO {
    id: string;
    username: string;
}

export interface AuthJwtDTO extends JwtDTO<AuthDTO> { }
