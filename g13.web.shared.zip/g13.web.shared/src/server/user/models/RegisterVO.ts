export interface RegisterVO {
    id: string;
    account_id: string;

    display_name: string;
    email: string;
    address: string;
    tel: string;

    username: string;
    password: string;

    platform_id: number;
}
