
export interface QueryUserVO {
    limit: number;
    offset: number;
    pid: number;
}
