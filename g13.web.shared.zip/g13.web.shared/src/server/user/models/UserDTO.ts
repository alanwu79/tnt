
export interface UserDTO {
    id: string;
    account_id: string;
    username: string;

    display_name: string;
    tel: string;
    email: string;
    address: string;
    change_password: number;
    locked: boolean;

    parent_id: string;

    platform_code: string;
    platform_id: number;
    platform_name: string;

    role_code: string;
    role_id: number;
    role_name: string;

    status_code: string;
    status_id: number;
    status_name: string;

    created_at: number;
    created_by: string;
    updated_at: number;
    updated_by: string;
}
