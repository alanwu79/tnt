
export interface InviteUserDTO {
    token: string;
}
