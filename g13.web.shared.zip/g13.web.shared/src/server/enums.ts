export enum NodeEnvEnum {
  Production = "production",
  Development = "development",
  Test = "test",
}

export enum PlatformEnum {
  System = 1,
  SkyMap = 2,
  ElderWand = 3,
  DaolinWand = 4,
}

export enum UserRoleEnum {
  System = 1,
  Admin = 2,
  Staff = 3,
  Tenant = 4,
  Agent = 5,
  ProjectEngineer = 6,
  FieldEngineer = 7,
  Viewer = 8,
}
