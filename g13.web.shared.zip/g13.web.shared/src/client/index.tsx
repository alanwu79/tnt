// import * as React from 'react';

export interface IIndexProps {}

export default function Index(props: IIndexProps) {
  return <div>Index</div>;
}
